def find_common_elements(list1, list2):
    set1 = set(list1)
    set2 = set(list2)

    common_elements = set1.intersection(set2)

    return len(common_elements)

list1 = list(map(int, input("Enter the elements of the first list separated by spaces: ").split()))
list2 = list(map(int, input("Enter the elements of the second list separated by spaces: ").split()))

common_count = find_common_elements(list1, list2)
print(f"Number of common elements: {common_count}")
