def transpose_matrix(matrix):
    return [[matrix[j][i] for j in range(len(matrix))] for i in range(len(matrix[0]))]


def input_matrix():
    rows = int(input("Enter the number of rows in the matrix: "))
    print("Enter the elements of the matrix row by row (space-separated):")
    matrix = []
    for _ in range(rows):
        row = list(map(int, input().split()))
        matrix.append(row)
    return matrix

matrix = input_matrix()
transposed = transpose_matrix(matrix)

print("\nOriginal Matrix:")
for row in matrix:
    print(row)

print("\nTransposed Matrix:")
for row in transposed:
    print(row)
