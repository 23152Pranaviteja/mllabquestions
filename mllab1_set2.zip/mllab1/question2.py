def matrix_multiply(A, B):
    if len(A[0]) != len(B):
        return "Error: Matrices cannot be multiplied. Number of columns in A must equal number of rows in B."

    result = [[0 for _ in range(len(B[0]))] for _ in range(len(A))]

    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):
                result[i][j] += A[i][k] * B[k][j]

    return result

def get_matrix_input(name):
    rows = int(input(f"Enter the number of rows in matrix {name}: "))
    cols = int(input(f"Enter the number of columns in matrix {name}: "))
    print(f"Enter the elements of matrix {name} row by row:")
    return [[int(input(f"Element [{i+1}][{j+1}]: ")) for j in range(cols)] for i in range(rows)]

if __name__ == "__main__":
    print("Matrix Multiplication Program")
    A = get_matrix_input("A")
    B = get_matrix_input("B")
    result = matrix_multiply(A, B)
    if isinstance(result, str):
        print(result)
    else:
        print("The product of matrices A and B is:")
        for row in result:
            print(row)
